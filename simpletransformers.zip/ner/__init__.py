from simpletransformers.config.model_args import NERArgs
from simpletransformers.ner.ner_model import NERModel
