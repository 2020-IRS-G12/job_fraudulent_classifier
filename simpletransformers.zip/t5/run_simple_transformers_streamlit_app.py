#!/usr/bin/env python
from simpletransformers.streamlit.simple_view import streamlit_runner


streamlit_runner()
